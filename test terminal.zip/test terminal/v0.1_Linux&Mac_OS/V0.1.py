
from Tkinter import *
from tkMessageBox import *
import serial 
import time
#------------------------------------------------------------
global port_values
port_values=[]

def scan():
   
    available = []
    for i in range(256):
        try:
            s = serial.Serial(i)
            available.append( (i, s.portstr))
            s.close()  
        except serial.SerialException:
            pass
    return available

if scan():
      global port_number
      for port_number,s in scan():
        print "(%d) %s" % (port_number,s)
        port_values.append(s)
                 

else :
      print askokcancel(title = '?',
                  message = 'Can not find the port! ',
                  default = OK
                  )
#----------------------------------------------------------------
count=0
flag=0 

root = Tk()
root.geometry('360x560')
root.title('Balance Robot Sigma_1 Tester v1.0')
LabelFrame(height = 100,width = 200,text = "Device Test").place(x=23,y=450)
LabelFrame(height = 100,width = 100,text = "Control Test").place(x=240,y=450)

#------------------------------------------------------------
label_1 = Label(root,text = 'Baud Rate:')
label_1.place(x=20,y=400)
label_2 = Label(root,text = 'Port Set :')
label_2.place(x=20,y=425)


baud = Spinbox(root,
              bg='black',
              fg='green',
             values = (115200,57600,38400,
                       28800,19200,14400,
                       9600,4800,2400,
                       1200,300))

port = Spinbox(root,
              bg='black',
              fg='green',
             values = tuple(port_values))
             
baud.place(x=90,y=400)
port.place(x=90,y=425)


#------------------------------------------------------------

t = Text(root,bg='black',
              fg='green',
              height =23,
              width=40)
def display():
 t.config(state=NORMAL)
 t.insert(INSERT,'----------------Welcome!---------------\n')
 t.insert(INSERT,'   Balance Robot Sigma_1 Tester v1.0\n')
 t.insert(INSERT,'             Design by Kent\n')
 t.insert(INSERT,'                 2013.2\n')
 t.insert(INSERT,'---------------------------------------\n')
 t.config(state=DISABLED)

display() 
t.place(x=16,y=5)

#--button define-----------------------------------------------

def open_port():
    
     global ser
     p=port.get()
     ser = serial.Serial(port_number,timeout=1) # open serial port  
     v=baud.get()
     ser.baudrate=v
     t.config(state=NORMAL)
     t.insert(END,"Baud Rate: ")   
     t.insert(END,v)  
     t.insert(END,"\n") 
     t.insert(END,"Port: COM")   
     t.insert(END,port_number+1)  
     t.insert(END,"\n")  
     t.insert(END,"The Port is open now!")
     t.insert(END,"\n")         
     update_text()
     t.config(state=DISABLED)
    

def L_test(): 
   ser.write('L')
   data = ser.readline() 
   t.config(state=NORMAL)
   t.insert(END,data) 
   update_text()
   t.config(state=DISABLED)
  
   
def R_test(): 
   ser.write('R')
   data = ser.readline() 
   t.config(state=NORMAL)
   t.insert(END,data)  
   update_text()
   t.config(state=DISABLED)

def up(): 
   for i in range(20):
    ser.write('a')
   t.config(state=NORMAL)
   t.insert(END,"robot is going forward...\n")  
   update_text()
   t.config(state=DISABLED)

def down(): 
   for i in range(20):
    ser.write('b')
   t.config(state=NORMAL)
   t.insert(END,"robot is turing back...\n")  
   update_text()
   t.config(state=DISABLED)

def left(): 
   ser.write('l')
   t.config(state=NORMAL)
   t.insert(END,"robot is turing left...\n")  
   update_text()
   t.config(state=DISABLED)

def right(): 
   ser.write('r')
   t.config(state=NORMAL)
   t.insert(END,"robot is turing right...\n")  
   update_text()
   t.config(state=DISABLED)

def stop(): 
   ser.write('s')
   t.config(state=NORMAL)
   t.insert(END,"robot is stop...\n")  
   update_text()
   t.config(state=DISABLED)


 
def sensor():
   t.config(state=NORMAL)
   t.delete(1.0,END)
   display()
   global flag
   if flag==0:
       flag=1
       ser.write('S')
       data=ser.readline()
       a_x,a_y,a_z,g_x,g_y,g_z=data.split(',')
       t.config(state=NORMAL)
       v.set('Clear')
       t.insert(INSERT,'    Accelerometer:\n\n')
       t.insert(INSERT,'    X:')
       t.insert(INSERT,a_x)
       t.insert(INSERT,'    Y:')
       t.insert(INSERT,a_y)
       t.insert(INSERT,'    Z:')
       t.insert(INSERT,a_z)
    
       t.insert(INSERT,'\n\n')

       t.insert(INSERT,'    Gyroscope:\n\n')
       t.insert(INSERT,'    X:')
       t.insert(INSERT,g_x)
       t.insert(INSERT,'    Y:')
       t.insert(INSERT,g_y)
       t.insert(INSERT,'    Z:')
       t.insert(INSERT,g_z) 
       update_text()
       t.config(state=DISABLED)
   else:
       v.set('Sensor')
       flag=0
       #ser.write('L')
       #data=ser.readline()
      



v = StringVar()
Button(root,text = 'L_Motor',width = 7,height = 3,command = L_test).place(x=30,y=470)
Button(root,text = 'R_Motor',width = 7,height = 3,command = R_test).place(x=90,y=470)
Button(root,textvariable = v,width = 7,height = 3,command = sensor).place(x=150,y=470)
Button(root,text = 'Open',width = 6,height = 2,command = open_port).place(x=260,y=400)
v.set('Sensor')

Button(root,text = 'U',width = 2,height = 1,command = up).place(x=280,y=469)
Button(root,text = 'D',width = 2,height = 1,command = down).place(x=280,y=516)
Button(root,text = 'L',width = 2,height = 1,command = left).place(x=258,y=490)
Button(root,text = 'R',width = 2,height = 1,command = right).place(x=300,y=490)
Button(root,text = 'S',width = 2,height = 1,command = stop).place(x=280,y=490)


#---------------------------------------------------------------------------

def update_text():
   global count
   count=count+1
   if count>=16:
     t.yview_scroll(1, 'units')

#-----------------------------------------------------------------------------  

root.mainloop()

ser.close 

